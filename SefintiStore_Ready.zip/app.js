
let lang = localStorage.getItem('lang') || 'ar';
const WhatsAppBase = 'https://wa.me/212679613261';
async function load(){ 
  const res = await fetch('products.json'); 
  const data = await res.json(); 
  render(data);
  setLang(lang);
}
function render(items){
  const wrap = document.getElementById('grid');
  wrap.innerHTML = '';
  items.forEach(p=>{
    const title = lang==='ar'? p.name_ar : p.name_fr;
    const desc = lang==='ar'? p.desc_ar : p.desc_fr;
    const whats = encodeURIComponent((lang==='ar'?'مرحبا، أريد هذا المنتج: ':'Bonjour, je veux ce produit: ')+ title + ' | SKU: '+p.sku);
    const link = `${WhatsAppBase}?text=${whats}`;
    const card = document.createElement('div');
    card.className='prod';
    card.innerHTML = `
      <img src="assets/${p.img}" alt="${title}">
      <div class="info">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:8px">
          <strong>${title}</strong>
          <span class="price">${p.price}</span>
        </div>
        <small style="color:#a9bed1">${desc}</small>
        <a class="cta" href="${link}" target="_blank">${lang==='ar'?'اطلب عبر واتساب':'Commander via WhatsApp'}</a>
      </div>`;
    wrap.appendChild(card);
  });
}
function setLang(l){ 
  lang = l; 
  localStorage.setItem('lang',l); 
  document.getElementById('tagline').innerText = (l==='ar'?'منتجات مختارة بعناية، جودة وابتكار':'Produits soigneusement sélectionnés, qualité & innovation');
  document.getElementById('heroTitle').innerText = (l==='ar'?'رحلتك التسويقية تبدأ هنا':'Votre aventure shopping commence ici');
  document.getElementById('best').innerText = (l==='ar'?'أفضل العروض اليوم':'Meilleures offres du jour');
  document.getElementById('ctaHero').innerText = (l==='ar'?'تواصل معنا':'Contactez-nous');
  load();
}
window.addEventListener('DOMContentLoaded',load);
